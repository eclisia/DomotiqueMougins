#ifndef COMMAND_NOTIFICATIONS_H
#define COMMAND_NOTIFICATIONS_H

class String;

String Command_Notifications_Notify(struct EventStruct *event, const char* Line);

#endif // COMMAND_NOTIFICATIONS_H
