#ifndef GLOBALS_CACHE_H
#define GLOBALS_CACHE_H

#include "../DataStructs/Caches.h"

void clearAllCaches();

extern Caches Cache;

#endif // GLOBALS_CACHE_H