#ifndef GLOBALS_ESPEASY_SCHEDULER_H
#define GLOBALS_ESPEASY_SCHEDULER_H

#include "../Helpers/Scheduler.h"

extern ESPEasy_Scheduler Scheduler;

#endif // GLOBALS_ESPEASY_SCHEDULER_H