#include "../Globals/Device.h"

// TODO TD-er: Move often used functions like determine valueCount to here.

DeviceVector Device;