#include "MainLoopCommand.h"

byte cmd_within_mainloop = 0;