#ifndef GLOBALS_EVENTQUEUE_H
#define GLOBALS_EVENTQUEUE_H

#include "../DataStructs/EventQueue.h"

#include <list>

extern EventQueueStruct eventQueue;

#endif // GLOBALS_EVENTQUEUE_H