#ifndef GLOBALS_TXBUFFER_H
#define GLOBALS_TXBUFFER_H

#include "../DataStructs/Web_StreamingBuffer.h"

extern Web_StreamingBuffer TXBuffer;

#endif // GLOBALS_TXBUFFER_H