#ifndef GLOBALS_I2CDEV_H
#define GLOBALS_I2CDEV_H


#include <I2Cdev.h>


extern I2Cdev i2cdev;


#endif // ifndef GLOBALS_I2CDEV_H
