#ifndef GLOBALS_TIMEZONE_H
#define GLOBALS_TIMEZONE_H

#include "../Helpers/ESPEasy_time_zone.h"

extern ESPEasy_time_zone time_zone;


#endif // GLOBALS_TIMEZONE_H