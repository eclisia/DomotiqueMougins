#ifndef GLOBALS_PROTOCOL_H
#define GLOBALS_PROTOCOL_H

#include "../DataStructs/ProtocolStruct.h"

extern ProtocolVector Protocol;
extern int protocolCount;

#endif // GLOBALS_PROTOCOL_H