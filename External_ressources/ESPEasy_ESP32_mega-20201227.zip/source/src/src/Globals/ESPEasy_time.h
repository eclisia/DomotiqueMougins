#ifndef GLOBALS_ESPEASY_TIME_H
#define GLOBALS_ESPEASY_TIME_H

#include "../Helpers/ESPEasy_time.h"

extern ESPEasy_time node_time;



#endif // GLOBALS_ESPEASY_TIME_H