#include "ProtocolIndex.h"

#include "../CustomBuild/ESPEasyLimits.h"

protocolIndex_t   INVALID_PROTOCOL_INDEX   = CPLUGIN_MAX;