#ifndef DATASTRUCTS_CPLUGINID_H
#define DATASTRUCTS_CPLUGINID_H

#include <Arduino.h>


typedef uint8_t cpluginID_t;

extern cpluginID_t INVALID_C_PLUGIN_ID;


#endif // ifndef DATASTRUCTS_CPLUGINID_H
