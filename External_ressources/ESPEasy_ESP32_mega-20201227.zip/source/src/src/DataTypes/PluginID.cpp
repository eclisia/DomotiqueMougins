#include "PluginID.h"

pluginID_t     INVALID_PLUGIN_ID     = 0;