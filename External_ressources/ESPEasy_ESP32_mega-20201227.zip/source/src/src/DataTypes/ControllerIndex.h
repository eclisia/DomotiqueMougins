#ifndef DATASTRUCTS_CONTROLLERINDEX_H
#define DATASTRUCTS_CONTROLLERINDEX_H

#include <Arduino.h>

typedef byte    controllerIndex_t;

extern controllerIndex_t INVALID_CONTROLLER_INDEX;

#endif