#include "CPluginID.h"

cpluginID_t INVALID_C_PLUGIN_ID = 0;
