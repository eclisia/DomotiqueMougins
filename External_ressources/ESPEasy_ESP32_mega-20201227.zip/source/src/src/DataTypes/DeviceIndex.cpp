#include "DeviceIndex.h"

#include "../CustomBuild/ESPEasyLimits.h"

deviceIndex_t  INVALID_DEVICE_INDEX  = PLUGIN_MAX;