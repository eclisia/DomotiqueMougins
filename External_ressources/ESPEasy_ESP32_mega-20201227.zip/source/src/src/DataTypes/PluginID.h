#ifndef DATASTRUCT_PLUGINID_H
#define DATASTRUCT_PLUGINID_H

#include <Arduino.h>

typedef uint8_t  pluginID_t;

extern pluginID_t     INVALID_PLUGIN_ID;

#endif