#ifndef DATASTRUCTS_PROTOCOLINDEX_H
#define DATASTRUCTS_PROTOCOLINDEX_H

#include <Arduino.h>

typedef byte    protocolIndex_t;

extern protocolIndex_t   INVALID_PROTOCOL_INDEX;


#endif