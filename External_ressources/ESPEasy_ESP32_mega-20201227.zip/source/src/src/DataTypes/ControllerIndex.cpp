#include "ControllerIndex.h"

#include "../CustomBuild/ESPEasyLimits.h"

controllerIndex_t INVALID_CONTROLLER_INDEX = CONTROLLER_MAX;