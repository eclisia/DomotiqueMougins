#ifndef HELPERS_MDNS_HELPER_H
#define HELPERS_MDNS_HELPER_H

#include "../../ESPEasy_common.h"

void set_mDNS();


#endif