#ifndef WEBSERVER_WEBSERVER_LOADFROMFS_H
#define WEBSERVER_WEBSERVER_LOADFROMFS_H

#include "../WebServer/common.h"


bool loadFromFS(boolean spiffs, String path);

#endif