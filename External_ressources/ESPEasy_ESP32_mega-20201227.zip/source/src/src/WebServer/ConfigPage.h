#ifndef WEBSERVER_WEBSERVER_CONFIGPAGE_H
#define WEBSERVER_WEBSERVER_CONFIGPAGE_H


#include "../WebServer/common.h"


#ifdef WEBSERVER_CONFIG

// ********************************************************************************
// Web Interface config page
// ********************************************************************************
void handle_config();

#endif // ifdef WEBSERVER_CONFIG



#endif