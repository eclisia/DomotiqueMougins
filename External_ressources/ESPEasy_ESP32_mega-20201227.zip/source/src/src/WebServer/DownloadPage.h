#ifndef WEBSERVER_WEBSERVER_DOWNLOADPAGE_H
#define WEBSERVER_WEBSERVER_DOWNLOADPAGE_H

#include "../WebServer/common.h"

#ifdef WEBSERVER_DOWNLOAD

// ********************************************************************************
// Web Interface download page
// ********************************************************************************
void handle_download();

#endif // ifdef WEBSERVER_DOWNLOAD


#endif // ifndef WEBSERVER_WEBSERVER_DOWNLOADPAGE_H
