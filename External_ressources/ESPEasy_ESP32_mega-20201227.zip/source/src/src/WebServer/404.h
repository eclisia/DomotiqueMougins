#ifndef WEBSERVER_WEBSERVER_404_H
#define WEBSERVER_WEBSERVER_404_H

#include "../WebServer/common.h"


void handleNotFound();


#endif