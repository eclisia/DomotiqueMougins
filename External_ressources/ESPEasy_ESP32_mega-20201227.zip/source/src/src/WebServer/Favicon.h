#ifndef WEBSERVER_WEBSERVER_FAVICON_H
#define WEBSERVER_WEBSERVER_FAVICON_H

#include "../WebServer/common.h"

void handle_favicon();


#endif