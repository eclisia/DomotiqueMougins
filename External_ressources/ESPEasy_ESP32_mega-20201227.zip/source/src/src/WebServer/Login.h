#ifndef WEBSERVER_WEBSERVER_LOGIN_H
#define WEBSERVER_WEBSERVER_LOGIN_H

#include "../WebServer/common.h"


// ********************************************************************************
// Web Interface login page
// ********************************************************************************
void handle_login();


#endif