#ifndef WEBSERVER_WEBSERVER_LOG_H
#define WEBSERVER_WEBSERVER_LOG_H

#include "../WebServer/common.h"


// ********************************************************************************
// Web Interface log page
// ********************************************************************************
void handle_log();

// ********************************************************************************
// Web Interface JSON log page
// ********************************************************************************
void handle_log_JSON();



#endif