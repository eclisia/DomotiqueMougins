#ifndef WEBSERVER_WEBSERVER_NOTIFICATIONPAGE_H
#define WEBSERVER_WEBSERVER_NOTIFICATIONPAGE_H

#include "../WebServer/common.h"

// ********************************************************************************
// Web Interface notifcations page
// ********************************************************************************

#ifdef USES_NOTIFIER

void handle_notifications();

#endif // USES_NOTIFIER


#endif