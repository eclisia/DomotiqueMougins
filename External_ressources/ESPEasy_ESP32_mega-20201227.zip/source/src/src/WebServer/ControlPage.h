#ifndef WEBSERVER_WEBSERVER_CONTROLPAGE_H
#define WEBSERVER_WEBSERVER_CONTROLPAGE_H

#include "../WebServer/common.h"

#ifdef WEBSERVER_CONTROL


// ********************************************************************************
// Web Interface control page (no password!)
// ********************************************************************************
void handle_control();

#endif // ifdef WEBSERVER_CONTROL


#endif // ifndef WEBSERVER_WEBSERVER_CONTROLPAGE_H
